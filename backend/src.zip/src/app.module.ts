import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';

import { ScoreService } from './score/score.service';
import { RecommendationService } from './recommendations/recommendation.service';
import { OpenAIService } from './ai/openai.service';

@Module({
  imports: [],
  controllers: [AppController],
 providers: [
  AppService,
  ScoreService,
  RecommendationService,
  OpenAIService,
],
})
export class AppModule {}