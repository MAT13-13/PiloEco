"use client";

import { useEffect, useState } from "react";
import { supabase } from "./lib/supabase";
import type { User } from "@supabase/supabase-js";

import Sidebar from "./components/Sidebar";
import DashboardHero from "./components/DashboardHero";
import StatsCards from "./components/StatsCards";
import ModuleGrid from "./components/ModuleGrid";
import AnalysisForm from "./components/AnalysisForm";
import HistoryList from "./components/HistoryList";
import PiloCard from "./components/PiloCard";
import PiloAssistant from "./components/PiloAssistant";

type Recommandation = {
  categorie: string;
  priorite: string;
  economie: number;
  action: string;
};

type ResultatEconomies = {
  economiePossible: number;
  economieAnnuelle: number;
  totalDepenses: number;
  scorePilo: number;
  recommandations: Recommandation[];
  diagnosticIA: string;
  priorites: string[];
};

type Analyse = {
  id: string;
  telephone: number;
  internet: number;
  assurance: number;
  electricite: number;
  total_depenses: number;
  economie_possible: number;
  economie_annuelle: number;
  created_at: string;
};

export default function Home() {
  const [user, setUser] = useState<User | null>(null);

  const [email, setEmail] = useState("");
  const [motDePasse, setMotDePasse] = useState("");

  const [telephone, setTelephone] = useState("");
  const [internet, setInternet] = useState("");
  const [assurance, setAssurance] = useState("");
  const [electricite, setElectricite] = useState("");

  const [resultat, setResultat] = useState<ResultatEconomies | null>(null);
  const [analyses, setAnalyses] = useState<Analyse[]>([]);

  const [chargement, setChargement] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setUser(data.user);

      if (data.user) {
        chargerAnalyses(data.user.id);
      }
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);

      if (session?.user) {
        chargerAnalyses(session.user.id);
      } else {
        setAnalyses([]);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  async function chargerAnalyses(utilisateurId: string) {
    const { data, error } = await supabase
      .from("analyses")
      .select("*")
      .eq("utilisateur_id", utilisateurId)
      .order("created_at", { ascending: false });

    if (!error && data) {
      setAnalyses(data as Analyse[]);
    }
  }

  async function inscription() {
    setChargement(true);
    setMessage("");

    const { data, error } = await supabase.auth.signUp({
      email,
      password: motDePasse,
    });

    if (error) {
      setMessage(error.message);
    } else {
      if (data.user) {
        await supabase.from("profils").insert({
          id: data.user.id,
          email,
        });
      }

      setMessage("Compte créé. Vérifie tes emails pour confirmer ton compte.");
    }

    setChargement(false);
  }

  async function connexion() {
    setChargement(true);
    setMessage("");

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password: motDePasse,
    });

    if (error) {
      setMessage(error.message);
    } else {
      setMessage("Connexion réussie.");
    }

    setChargement(false);
  }

  async function deconnexion() {
    await supabase.auth.signOut();
    setResultat(null);
    setAnalyses([]);
    setMessage("Déconnexion réussie.");
  }

  async function calculerEconomies() {
    if (!user) {
      alert("Tu dois être connecté pour enregistrer une analyse.");
      return;
    }

    try {
      const response = await fetch("http://localhost:3001/calcul-economies", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          telephone: Number(telephone),
          internet: Number(internet),
          assurance: Number(assurance),
          electricite: Number(electricite),
        }),
      });

      const data = await response.json();

      setResultat(data);

      const { error } = await supabase.from("analyses").insert({
        utilisateur_id: user.id,
        telephone: Number(telephone),
        internet: Number(internet),
        assurance: Number(assurance),
        electricite: Number(electricite),
        total_depenses: data.totalDepenses,
        economie_possible: data.economiePossible,
        economie_annuelle: data.economieAnnuelle,
      });

      if (error) {
        setMessage("Le calcul a fonctionné, mais l'analyse n'a pas été enregistrée.");
      } else {
        setMessage("Analyse enregistrée avec succès.");
        chargerAnalyses(user.id);
      }
    } catch {
      alert("Erreur connexion backend");
    }
  }

  const totalEconomiesMensuelles = analyses.reduce(
    (total, analyse) => total + Number(analyse.economie_possible || 0),
    0
  );

  const totalEconomiesAnnuelles = analyses.reduce(
    (total, analyse) => total + Number(analyse.economie_annuelle || 0),
    0
  );

  if (!user) {
    return (
      <main className="min-h-screen bg-slate-950 text-white flex items-center justify-center p-6">
        <section className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 p-8">
          <p className="text-center text-green-400 font-bold mb-3">PiloEco</p>

          <h1 className="text-4xl font-bold text-center mb-4">
            Connecte-toi
          </h1>

          <p className="text-center text-slate-300 mb-8">
            Crée ton compte ou connecte-toi pour accéder à ton espace.
          </p>

          <div className="space-y-4">
            <input
              type="email"
              placeholder="Ton email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-xl p-4 bg-white text-black placeholder:text-slate-500"
            />

            <input
              type="password"
              placeholder="Mot de passe"
              value={motDePasse}
              onChange={(e) => setMotDePasse(e.target.value)}
              className="w-full rounded-xl p-4 bg-white text-black placeholder:text-slate-500"
            />

            <button
              onClick={connexion}
              disabled={chargement}
              className="w-full bg-green-500 hover:bg-green-600 disabled:opacity-50 text-black font-bold py-4 rounded-xl transition"
            >
              Se connecter
            </button>

            <button
              onClick={inscription}
              disabled={chargement}
              className="w-full bg-white hover:bg-slate-200 disabled:opacity-50 text-black font-bold py-4 rounded-xl transition"
            >
              Créer un compte
            </button>
          </div>

          {message && (
            <p className="mt-6 text-center text-sm text-slate-300">
              {message}
            </p>
          )}
        </section>
      </main>
    );
  }

  return (
    <>
      <Sidebar />

      <main className="min-h-screen bg-slate-950 text-white p-6 lg:ml-64">
        <section className="mx-auto w-full max-w-6xl">
          <div className="mb-8 flex items-center justify-end">
            <button
              onClick={deconnexion}
              className="rounded-xl bg-slate-800 hover:bg-slate-700 px-4 py-2 text-sm"
            >
              Déconnexion
            </button>
          </div>

          <DashboardHero
            email={user.email}
            analysesCount={analyses.length}
            economieMensuelle={totalEconomiesMensuelles}
            economieAnnuelle={totalEconomiesAnnuelles}
          />

          <ModuleGrid />

          <StatsCards
            analyses={analyses.length}
            economieMensuelle={totalEconomiesMensuelles}
            economieAnnuelle={totalEconomiesAnnuelles}
          />

          <div className="grid gap-8 lg:grid-cols-2">
            <div>
              <AnalysisForm
                telephone={telephone}
                internet={internet}
                assurance={assurance}
                electricite={electricite}
                setTelephone={setTelephone}
                setInternet={setInternet}
                setAssurance={setAssurance}
                setElectricite={setElectricite}
                calculerEconomies={calculerEconomies}
                resultat={resultat}
                message={message}
              />

              {resultat !== null && (
                <>
                  <PiloCard economie={resultat.economiePossible} />

                  <PiloAssistant
  score={resultat.scorePilo}
  savings={resultat.economieAnnuelle}
  recommandations={resultat.recommandations || []}
  conseilsIA={[resultat.diagnosticIA || ""]}
/>
                </>
              )}
            </div>

            <HistoryList analyses={analyses} />
          </div>
        </section>
      </main>
    </>
  );
}