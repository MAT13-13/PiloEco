import type { Depense } from "./depenses.service";

export type Mission = {
  title: string;
  description: string;
  reward: string;
};

export function generateMissions(depenses: Depense[]): Mission[] {
  const missions: Mission[] = [];

  const restaurants = depenses.filter(
    (d) => d.category === "Restaurant"
  );

  if (restaurants.length > 0) {
    missions.push({
      title: "Limiter les restaurants",
      description:
        "Essaie de préparer deux repas cette semaine.",
      reward: "+3 points",
    });
  }

  const abonnements = depenses.filter(
    (d) => d.category === "Abonnement"
  );

  if (abonnements.length > 1) {
    missions.push({
      title: "Faire le tri",
      description:
        "Vérifie si un abonnement peut être supprimé.",
      reward: "+2 points",
    });
  }

  missions.push({
    title: "Comparer une assurance",
    description:
      "Demande un devis pour ton assurance habitation.",
    reward: "+5 points",
  });

  return missions;
}