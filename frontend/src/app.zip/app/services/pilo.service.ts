import type { Depense } from "./depenses.service";
import { calculateEconomyScore } from "./score.service";

export type PiloAnalysis = {
  greeting: string;
  summary: string;
  score: number;
  totalSavings: number;
  insights: {
    icon: string;
    title: string;
    message: string;
    saving: number;
  }[];
};

export function analyzePilo(depenses: Depense[]): PiloAnalysis {
  const result = calculateEconomyScore(depenses);

  let greeting = "Bonjour 👋";
  let summary = "Continue comme ça.";

  if (result.score >= 90) {
    summary = "Excellent ! Tes finances sont très bien gérées.";
  } else if (result.score >= 75) {
    summary =
      "Très bon travail. Quelques optimisations peuvent encore augmenter tes économies.";
  } else if (result.score >= 60) {
    summary =
      "Tu peux améliorer ton budget avec quelques ajustements ciblés.";
  } else {
    summary =
      "Pilo a détecté plusieurs opportunités importantes d'économies.";
  }

  return {
    greeting,
    summary,
    score: result.score,
    totalSavings: result.totalSavings,
    insights: result.insights,
  };
}