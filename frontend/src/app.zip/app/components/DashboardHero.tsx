type DashboardHeroProps = {
  email: string | undefined;
  analysesCount: number;
  economieMensuelle: number;
  economieAnnuelle: number;
};

export default function DashboardHero({
  email,
  analysesCount,
  economieMensuelle,
  economieAnnuelle,
}: DashboardHeroProps) {
  return (
    <section className="mb-8 rounded-3xl border border-slate-800 bg-gradient-to-br from-slate-900 to-slate-950 p-8">
      <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <p className="mb-2 text-sm font-bold uppercase tracking-wide text-green-400">
            Tableau de bord
          </p>

          <h1 className="text-4xl font-bold text-white">
            👋 Bonjour Fiona
          </h1>

          <p className="mt-3 max-w-2xl text-slate-300">
            Ton copilote est prêt. Aujourd’hui, Pilo t’aide à repérer les
            économies les plus simples à activer.
          </p>

          <p className="mt-2 text-sm text-slate-500">{email}</p>
        </div>

        <div className="rounded-2xl border border-green-500/40 bg-green-500/10 p-5 text-center">
          <p className="text-sm text-green-300">Économies détectées</p>
          <p className="mt-2 text-4xl font-bold text-green-400">
            {economieMensuelle} €
          </p>
          <p className="mt-1 text-sm text-slate-400">par mois</p>
        </div>
      </div>

      <div className="mt-8 grid gap-4 md:grid-cols-3">
        <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5">
          <p className="text-slate-400">Analyses réalisées</p>
          <p className="mt-2 text-3xl font-bold">{analysesCount}</p>
        </div>

        <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5">
          <p className="text-slate-400">Économies annuelles</p>
          <p className="mt-2 text-3xl font-bold text-green-400">
            {economieAnnuelle} €
          </p>
        </div>

        <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5">
          <p className="text-slate-400">Mission du jour</p>
          <p className="mt-2 font-bold text-white">
            Comparer ton assurance
          </p>
          <p className="mt-1 text-sm text-slate-500">
            C’est souvent là qu’on gagne le plus vite.
          </p>
        </div>
      </div>
    </section>
  );
}