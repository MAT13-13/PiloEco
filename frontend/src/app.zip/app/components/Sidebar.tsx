export default function Sidebar() {
  return (
    <aside className="fixed left-0 top-0 hidden h-screen w-64 border-r border-slate-800 bg-slate-950 p-6 text-white lg:block">
      <div className="mb-10">
        <h1 className="text-2xl font-bold text-green-400">MonEcoPilote</h1>
        <p className="mt-1 text-sm text-slate-400">Ton copilote d’économies</p>
      </div>

      <nav className="space-y-3">
        <button className="w-full rounded-xl bg-green-500 px-4 py-3 text-left font-semibold text-slate-950">
          🏠 Tableau de bord
        </button>

        <button className="w-full rounded-xl px-4 py-3 text-left text-slate-300 hover:bg-slate-800">
          💰 Économies
        </button>

        <button className="w-full rounded-xl px-4 py-3 text-left text-slate-300 hover:bg-slate-800">
          🏡 Mon Nid
        </button>

        <button className="w-full rounded-xl px-4 py-3 text-left text-slate-300 hover:bg-slate-800">
          📱 Abonnements
        </button>

        <button className="w-full rounded-xl px-4 py-3 text-left text-slate-300 hover:bg-slate-800">
          🛡️ Assurances
        </button>

        <button className="w-full rounded-xl px-4 py-3 text-left text-slate-300 hover:bg-slate-800">
          ⚡ Énergie
        </button>

        <button className="w-full rounded-xl px-4 py-3 text-left text-slate-300 hover:bg-slate-800">
          🚗 Mobilité
        </button>

        <button className="w-full rounded-xl px-4 py-3 text-left text-slate-300 hover:bg-slate-800">
          🐶 Animaux
        </button>

        <button className="w-full rounded-xl px-4 py-3 text-left text-slate-300 hover:bg-slate-800">
          🤖 IA Conseils
        </button>
      </nav>

      <div className="absolute bottom-6 left-6 right-6 rounded-xl border border-slate-800 bg-slate-900 p-4">
        <p className="text-sm text-slate-400">Version actuelle</p>
        <p className="font-bold text-green-400">Gratuite</p>
      </div>
    </aside>
  );
}