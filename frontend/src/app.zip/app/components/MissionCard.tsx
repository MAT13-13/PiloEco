"use client";

type Mission = {
  title: string;
  description: string;
  reward: string;
};

const missions: Mission[] = [
  {
    title: "Limiter les restaurants",
    description: "Ne dépasse pas 25 € en restauration cette semaine.",
    reward: "+3 points Score Économie",
  },
  {
    title: "Vérifier les abonnements",
    description: "Repère un abonnement inutile ou trop cher.",
    reward: "+2 points Score Économie",
  },
  {
    title: "Comparer une offre",
    description: "Compare ton forfait mobile ou ton assurance habitation.",
    reward: "+5 points Score Économie",
  },
];

export default function MissionCard() {
  return (
    <section className="mt-8 rounded-3xl border border-green-500/20 bg-slate-900 p-8">
      <p className="text-sm font-bold uppercase text-green-400">
        Mode Mission
      </p>

      <h2 className="mt-3 text-3xl font-black text-white">
        🎯 Missions de la semaine
      </h2>

      <p className="mt-3 text-slate-400">
        Pilo te propose des défis simples pour économiser sans te priver.
      </p>

      <div className="mt-6 grid gap-5 md:grid-cols-3">
        {missions.map((mission) => (
          <div
            key={mission.title}
            className="rounded-2xl bg-slate-950 p-6"
          >
            <h3 className="text-xl font-bold text-white">
              {mission.title}
            </h3>

            <p className="mt-3 text-slate-400">
              {mission.description}
            </p>

            <p className="mt-5 rounded-xl bg-green-500/10 p-3 text-sm font-bold text-green-400">
              🎁 {mission.reward}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}