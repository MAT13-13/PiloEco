type StatsCardsProps = {
  analyses: number;
  economieMensuelle: number;
  economieAnnuelle: number;
};

export default function StatsCards({
  analyses,
  economieMensuelle,
  economieAnnuelle,
}: StatsCardsProps) {

  const scorePilo = Math.min(
    100,
    Math.round(
      analyses * 8 +
      economieMensuelle / 10
    )
  );

  return (
    <div className="grid gap-4 md:grid-cols-4 mb-8">

      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6">
        <p className="text-slate-400">
          Analyses réalisées
        </p>

        <p className="mt-2 text-4xl font-bold">
          {analyses}
        </p>
      </div>

      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6">
        <p className="text-slate-400">
          Économies mensuelles
        </p>

        <p className="mt-2 text-4xl font-bold text-green-400">
          {economieMensuelle} €
        </p>
      </div>

      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6">
        <p className="text-slate-400">
          Économies annuelles
        </p>

        <p className="mt-2 text-4xl font-bold text-green-400">
          {economieAnnuelle} €
        </p>
      </div>

      <div className="rounded-2xl bg-gradient-to-br from-green-500 to-emerald-700 p-6 text-black">
        <p className="font-semibold">
          Score Pilo
        </p>

        <p className="mt-2 text-5xl font-extrabold">
          {scorePilo}/100
        </p>

        <div className="mt-4 h-3 rounded-full bg-white/30">
          <div
            className="h-3 rounded-full bg-black transition-all duration-500"
            style={{ width: `${scorePilo}%` }}
          />
        </div>

        <p className="mt-4 text-sm font-medium">
          Plus ton score est élevé, plus PiloEco estime que tes finances sont optimisées.
        </p>
      </div>

    </div>
  );
}