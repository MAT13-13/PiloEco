export type Offer = {
  id: number;
  category: string;
  provider: string;
  monthlyPrice: number;
  yearlySaving: number;
  affiliateUrl: string;
};

export const offers: Offer[] = [
  {
    id: 1,
    category: "Assurance habitation",
    provider: "Partenaire Habitat",
    monthlyPrice: 24,
    yearlySaving: 96,
    affiliateUrl: "#",
  },
  {
    id: 2,
    category: "Forfait mobile",
    provider: "Partenaire Mobile",
    monthlyPrice: 9.99,
    yearlySaving: 120,
    affiliateUrl: "#",
  },
  {
    id: 3,
    category: "Assurance animaux",
    provider: "Propoil",
    monthlyPrice: 14.90,
    yearlySaving: 84,
    affiliateUrl: "#",
  },
];